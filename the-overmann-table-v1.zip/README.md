# The Overmann Table

A clean, responsive recipe website. Static HTML/CSS/JavaScript; no build step or paid services required.

## Launch
Upload **all four files** (`index.html`, `style.css`, `script.js`, `recipes.json`) to the root of your GitHub repository. For Cloudflare Pages, choose **Workers & Pages → Create → Pages → Connect to Git**, select the repository, choose **no framework**, leave the build command blank, and set the output directory to `/` (or the default root output, depending on the interface).

## Add recipes
Edit `recipes.json`. Copy an existing recipe object, change its unique `id`, title, category, time (minutes), servings, description, image URL, ingredients and steps. Set `demo` to `false` for real recipes. The four included recipes are **illustrative samples**, not Nathan's verified recipes. Remove/replace them before sharing widely.

## Notes
- All content is public; do not store private family details or credentials here.
- Photos are loaded from Unsplash URLs and require internet access. Replace with your own properly licensed photos when available.
- Ingredient amounts scale numerically; some culinary quantities may require human judgment when scaled.
- Printing works from the recipe popup. Search includes ingredient names.
- Open via a local web server or hosted site; opening `index.html` directly as a `file://` URL may block the JSON fetch.
